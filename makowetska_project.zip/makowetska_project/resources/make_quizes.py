import pandas as pd
from random import choice
from random import randint

def make_quiz():
    questions = []
    answers = []
    actions = [' + ',' - ']
    for i in range(21):
        a = randint(0,100)
        b = randint(0,100)
        act = choice(actions)
        questions += [str(a) + act + str(b) + " = "]
        if act == " + ":
            ans = a + b
        else: ans = a - b
        answers += [ans]
    return  questions, answers

q,a = make_quiz()
in_dict = {'question': q, 'correct' : a}
df = pd.DataFrame(in_dict)
df['wrong1'] = df['correct'] +1 
df['wrong2'] = df['correct'] -1 
df[','] = [',' for i in range(21)]
f1 = "quiz3.csv"
f = open(f1, "w")
df.to_csv(f, sep=',', encoding='utf-8', index = False)
f.close()

f = open("quiz3.json", "w")
df.to_json(f, orient = "columns")
f.close()





q,a = make_quiz()
in_dict = {'question': q, 'correct' : a}
df = pd.DataFrame(in_dict)
df['wrong1'] = df['correct'] +1 
df['wrong2'] = df['correct'] -1 
df[','] = [',' for i in range(21)]
f1 = "quiz1.csv"
f = open(f1, "w")
df.to_csv(f, sep=',', encoding='utf-8', index = False)
f.close()
f = open("quiz1.json", "w")
df.to_json(f, orient = "columns")
f.close()
def make_quiz1():
    questions = []
    answers = []
    actions = [' + ',' - ']
    for i in range(21):
        a = randint(0,100)
        b = randint(0,100)
        c = randint(0,100)
        act1 = choice(actions)
        act2 = choice(actions)
        questions += [str(a) + act1 + str(b) + act2 + str(c) + " = "]
        if act1 == " + ":
            ans = a + b
        else: ans = a - b
        
        if act2 == " + ":
            ans = ans + c
        else: ans = ans - c
        answers += [ans]
    return  questions, answers

q,a = make_quiz1()
in_dict = {'question': q, 'correct' : a}
df = pd.DataFrame(in_dict)
df['wrong1'] = df['correct'] +1 
df['wrong2'] = df['correct'] -1 
df[','] = [',' for i in range(21)]
f1 = "quiz2.csv"
f = open(f1, "w")
df.to_csv(f, sep=',', encoding='utf-8', index = False)
f.close()
f = open("quiz2.json", "w")
df.to_json(f, orient = "columns")
f.close()

q,a = make_quiz1()
in_dict = {'question': q, 'correct' : a}
df = pd.DataFrame(in_dict)
df['wrong1'] = df['correct'] +1 
df['wrong2'] = df['correct'] -1
df[','] = [',' for i in range(21)]

f1 = "quiz4.csv"
f = open(f1, "w")
df.to_csv(f, sep=',', encoding='utf-8', index = False)
f.close()
f = open("quiz4.json", "w")
df.to_json(f, orient = "columns")
f.close()