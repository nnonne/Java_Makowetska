package quiz_maker;
import java.util.Random;
import java.util.Scanner;

import emails.SendEmail;
import quiz_maker.Question;
import read_files.ReadCSV;

public class Main {
	public static void main(String[] args) {
		String password = "password";
		Scanner in = new Scanner(System.in);
		System.out.print("Input your username: ");
		String username = in.nextLine();
		System.out.print("Choose your mode: T or S\n");
		String mode = in.nextLine();
		//System.out.print(mode);
		int score;
		String[] files = {"D:\\quiz1.csv","D:\\quiz2.csv","D:\\quiz3.csv","D:\\quiz4.csv"};
		if (mode == "T") {
			System.out.print("Input your password: ");
			String pass = in.nextLine();
			if (pass != password) {
				System.out.print("Access denied\n");
			}
			else {
				System.out.print("Add a new filename");
				files[files.length] = in.nextLine();
			}
		}
		else {
			System.out.print("Input your email: ");
			String email = in.nextLine();
			//int score; 
			ReadCSV el = new ReadCSV();
			Random random = new Random();
			score = el.readCSV(files[random.nextInt(4)]);
			System.out.print("Your score is: " + score + "\n");
			String to = "kmakowetska@gmail.com";
			SendEmail sm = new SendEmail(to);
			sm.send(score);
			
		}
		in.close();
		
		
		
		
	}
}
