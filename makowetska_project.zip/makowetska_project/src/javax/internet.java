package javax;

public class internet {

}
