package javax;

public class activation {

}
