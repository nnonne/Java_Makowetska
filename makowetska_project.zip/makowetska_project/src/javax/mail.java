package javax;

public class mail {

}
