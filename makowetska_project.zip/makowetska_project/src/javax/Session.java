package javax;
import java.util.*;

public class Session {
	public void getDefaultInstance(Properties pr) {
		
	}
}
