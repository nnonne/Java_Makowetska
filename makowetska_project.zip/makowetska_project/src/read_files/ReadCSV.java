package read_files;
import java.io.*;  
import java.util.Scanner;  
import quiz_maker.Question;
import java.util.ArrayList;
import java.util.List;
//import java.util.Random;


public class ReadCSV {
	public static Question makeQuestion(String line) {
		if (line != null) {
		String[] line1 = line.split(",");
		//System.out.print(line1);
		String q = line1[0].replace("\n", "");
		String a = line1[1].replace("\n", "");
		String w1 = line1[2].replace("\n", "");
		String w2 = line1[3].replace("\n", "");
		Question ans = new Question(q,a,w1,w2);
		return ans;
		}
		else {
			Question ans = new Question();
			return ans;
		}
	}
	
	public static int readCSV(String file) {
		try {
		Scanner sc = new Scanner(new File(file));  
		sc.useDelimiter("/n");    
		List<String> all_lines = new ArrayList<String>();  
		while (sc.hasNext()){ 
			String line = sc.next();
			all_lines.add(line);
		    }  
		String [] all_lines1 = all_lines.get(0).split("\n");
		for (int j = 1; j<all_lines1.length; j+=1) {
			Question q = makeQuestion(all_lines1[j]);
				q.Ask();
		}
		sc.close();}
		catch(IOException e){
            System.out.println("Error reading from file '"+ file + "'");           
        } 
		//Random random = new Random();
		
		//return random.nextInt(20);
		return 0;
}
	public static void main(String[] args) throws Exception  {   
		Scanner sc = new Scanner(new File("D:\\quiz1.csv"));  
		sc.useDelimiter("/n");    
		List<String> all_lines = new ArrayList<String>();  
		while (sc.hasNext()){ 
			String line = sc.next();
			all_lines.add(line);
		    }  
		String [] all_lines1 = all_lines.get(0).split("\n");
		for (int j = 1; j<all_lines1.length; j+=1) {
			Question q = makeQuestion(all_lines1[j]);
				q.Ask();
			
		}
		
		
	sc.close();   
	}   
}
