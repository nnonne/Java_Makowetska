package quiz_maker;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
//import read_files.ReadCSV;

public class Question {
	Scanner in = new Scanner(System.in);
	private String question;
	private String answer;
	private String wrong1;
	private String wrong2;
	private boolean answered;
	//private boolean correct;
	public Question(String question, String answer, String wrong1, String wrong2) {
		this.question = question;
		this.answer = answer;
		this.wrong1 = wrong1;
		this.wrong2 = wrong2;
		this.answered = false;
		//this.correct = false;
		//System.out.println(this.toString());
	}
	public Question() {
		this.question = "broken_question";
		this.answer = "no";
		this.wrong1 = "no";
		this.wrong2 = "no";
		this.answered =true;
		//this.correct = false;
	}
	
	private void Answer(String ans) {
		this.answered = true;
		//if (ans == this.answer) { this.correct = true;}
		//else {this.correct = false;}
	}
	private static void shuffleArray(int[] array){
	    int index, temp;
	    Random random = new Random();
	    for (int i = array.length - 1; i > 0; i--)
	    {
	        index = random.nextInt(i + 1);
	        temp = array[index];
	        array[index] = array[i];
	        array[i] = temp;
	    }
	}
	public String toString() {
		List<String> list = new ArrayList<>();
		list.add(this.answer);
		list.add(this.wrong1);
		list.add(this.wrong2);
		int[] indexes = {0,1,2};
		shuffleArray(indexes);
		String ans = "\n�������: " + this.question + "\n������� ��������: " + list.get(indexes[0]) + " "
				+ list.get(indexes[1]) + " " + list.get(indexes[2]) + "\n"; 
		return ans;
	}
	public void Ask() {
		System.out.print(this.toString() );
		
		String answer = in.nextLine();
		this.Answer(answer);
		//in.close();
		//System.out.print((answer = this.answer) );
		System.out.println( "\nCorrect answer is "+ this.answer + "\n" );
		
		
	}
	public boolean isAnswered() {
		return this.answered;
	}
	public static void main(String[] args) {
		Question q = new Question("1", "2","3","4");
		System.out.print(q.answer + "\n");
		q.Ask();
		q.Ask();
	}
}
